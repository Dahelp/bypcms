# BYPCMS runtime storage

config.php and installed.lock are generated on the production server.
They are never stored in Git or replaced by deployment.
